import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

public class ReadUserServlet extends HttpServlet
{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String user = request.getParameter("user");
		
		out.println("<html>");
		out.println("<head><title>Some title</title></head>");
		out.println("<body bgcolor='orange'>");
		out.println("<h2>User Name: " + user + "</h2>");
		out.println("<form method='post' action='readCollege'>");
		out.println("College Name: <input type='text' name='college'><br>");
		out.println("<input type='submit' value='Send'>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
	
}