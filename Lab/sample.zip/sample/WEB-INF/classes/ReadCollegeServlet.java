import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

public class ReadCollegeServlet extends HttpServlet
{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String user = request.getParameter("user");
		String college = request.getParameter("college");
		
		out.println("<html>");
		out.println("<head><title>Some title</title></head>");
		out.println("<body bgcolor='lime'>");
		out.println("<h2>User Name: " + user + "</h2>");
		out.println("<h2>College Name: " + college + "</h2>");
		out.println("</body>");
		out.println("</html>");
	}
	
}