package com.me.advert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvertApplicationTests {

	@Test
	void contextLoads() {
	}

}
