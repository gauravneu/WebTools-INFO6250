package com.me.advert.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;

import com.me.advert.dao.UserDAO;
import com.me.advert.exception.AdvertException;
import com.me.advert.pojo.User;

@Controller
public class UserController {
	@GetMapping("/adduser.htm")
	public String addUserGet(ModelMap model, User user) {
		// command object
		model.addAttribute("user", user);

		// return form view
		return "addUserForm";
	}

	@PostMapping("/adduser.htm")
	public String addUserPost(@ModelAttribute("user") User user, BindingResult result, SessionStatus status, UserDAO userdao) {
		try {
			userdao.save(user);
		} catch (AdvertException e) {
			System.out.println("User cannot be Added: " + e.getMessage());
		}
		
		status.setComplete(); //mark it complete
		return "addedUser";
	}
}
