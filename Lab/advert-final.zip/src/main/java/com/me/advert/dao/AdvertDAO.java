package com.me.advert.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.query.Query;
import org.springframework.stereotype.Component;

import com.me.advert.exception.AdvertException;
import com.me.advert.pojo.Advert;
import com.me.advert.pojo.Category;
import com.me.advert.pojo.User;

@Component
public class AdvertDAO extends DAO {
    public void save(Advert advert) throws AdvertException {
        try {
            begin();
            getSession().save(advert);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdvertException("Could not delete advert", e);
        }
    }
    
    public List<Advert> list() {
		Query<Advert> query = getSession().createQuery("FROM Advert");
		List<Advert> list = query.list();
		return list;
	}
}