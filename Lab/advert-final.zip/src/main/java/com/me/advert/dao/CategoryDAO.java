package com.me.advert.dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.query.Query;
import org.springframework.stereotype.Component;

import com.me.advert.exception.AdvertException;
import com.me.advert.pojo.Category;

@Component
public class CategoryDAO extends DAO {
	public CategoryDAO() {
		System.out.println("*** Category DAO");
		//default constructor
	}
	
	public List<Category> list() {
		Query<Category> query = getSession().createQuery("FROM Category");
		List<Category> list = query.list();
		return list;
	}

    public void save(Category category) throws AdvertException {
        try {
            begin();
            getSession().save(category);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdvertException("Could not delete the category", e);
        }
    }
    
    public Category getCategory(long id) {
    	return getSession().get(Category.class, id);
    }
    
    public void deleteCategory(Category c) throws AdvertException {
        try {
            begin();
            getSession().delete(c);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdvertException("Could not delete the category", e);
        }
    }
    
    public void updateCategory(Category c) throws AdvertException {
        try {
            begin();
            getSession().update(c);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdvertException("Could not delete the category", e);
        }
    }
}