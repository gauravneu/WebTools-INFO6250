package com.me.advert.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Component;

import com.me.advert.exception.AdvertException;
import com.me.advert.pojo.User;

@Component
public class UserDAO extends DAO {

    public UserDAO() {
    }

    public void save(User user) throws AdvertException {
        try {
            begin();
            getSession().save(user);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new AdvertException("Could not delete user " + user.getName(), e);
        }
    }
    
    public void delete(User u) throws AdvertException {
    	begin();
    	getSession().delete(u);
    	commit();
    }
}