package com.me.advert.controller;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;

import com.me.advert.dao.AdvertDAO;
import com.me.advert.exception.AdvertException;
import com.me.advert.pojo.Advert;

@Controller
public class AdvertController {
	@GetMapping("/listadverts.htm")
	public String listAdvertsGet(HttpServletRequest request, AdvertDAO advertdao) {
		request.setAttribute("adverts", advertdao.list());
		return "viewAdverts";
	}

	@GetMapping("/addadvert.htm")
	public String addAdvertGet(ModelMap model, Advert advert) {
		model.addAttribute("advert", advert);
		// return form view
		return "addAdvertForm";
	}

	@PostMapping("/addadvert.htm")
	public String addAdvertPost(@ModelAttribute("advert") Advert advert, BindingResult result, SessionStatus status, AdvertDAO advertdao) {
		//File is in the memory, need to transfer to a file
		String fileName = "img_" + System.currentTimeMillis() + "" + new Random().nextInt(100000000) + "" + new Random().nextInt(100000000) + ".jpg";
		advert.setImagePath(fileName);
		try {
			advert.getImageFile().transferTo(new File("C:\\advertuploads\\" + fileName));
		} catch (IllegalStateException e1) {
			System.out.println("IllegalStateException: " + e1.getMessage());
		} catch (IOException e1) {
			System.out.println("IOException: " + e1.getMessage());
		}
	
		try {
			advertdao.save(advert);
		} catch (AdvertException e) {
			System.out.println("Advert cannot be Added: " + e.getMessage());
		}
		
		status.setComplete(); //mark it complete
		return "addedAdvert";
	}
}