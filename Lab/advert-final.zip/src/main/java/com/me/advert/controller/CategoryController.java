package com.me.advert.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;

import com.me.advert.dao.CategoryDAO;
import com.me.advert.exception.AdvertException;
import com.me.advert.pojo.Category;

@Controller
public class CategoryController {
	@GetMapping("/addcategory.htm")
	public String addCategoryGet(ModelMap model, Category category) {
		// command object
		model.addAttribute("category", category);

		// return form view
		return "addCategoryForm";
	}

	@PostMapping("/addcategory.htm")
	public String addCategoryPost(@ModelAttribute("category") Category category, BindingResult result,
			SessionStatus status, CategoryDAO categorydao) {
		
		try {
			categorydao.save(category);
		} catch (AdvertException e) {
			System.out.println("Category cannot be Added: " + e.getMessage());
		}
		status.setComplete(); // mark it complete
		return "addedCategory";
	}
}
