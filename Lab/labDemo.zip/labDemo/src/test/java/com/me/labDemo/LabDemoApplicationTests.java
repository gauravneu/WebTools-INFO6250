package com.me.labDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
