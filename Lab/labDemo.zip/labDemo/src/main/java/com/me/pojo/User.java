package com.me.pojo;

import org.springframework.stereotype.Component;

@Component
public class User {

	private String first;
	private String last;
	
	public User() {
		
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getLast() {
		return last;
	}

	public void setLast(String last) {
		this.last = last;
	}
	
	
}
