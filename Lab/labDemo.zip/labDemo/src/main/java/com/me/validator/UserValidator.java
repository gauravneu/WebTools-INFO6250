package com.me.validator;

import com.me.pojo.User;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class UserValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return User.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		
		ValidationUtils.rejectIfEmpty(errors, "first", "empty-first-name", "First Name cannot be blank");
		ValidationUtils.rejectIfEmpty(errors, "last", "empty-last-name", "Last Name cannot be blank");
	}
	
}
