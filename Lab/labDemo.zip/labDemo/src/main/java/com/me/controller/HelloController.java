package com.me.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloController {
	
	@GetMapping("/hello.htm")
	public String handleGet() {
		System.out.println("Hiii");
		return "hello-view";
	}
	
}
